'use strict';


/**
 * List Projects
 * Return a list of projects the user has been added to.
 *
 * returns List
 **/
exports.projectsGET = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "city" : "city",
  "name" : "name",
  "start" : 5,
  "client" : "client",
  "project" : "project",
  "progression" : 1.4658129805029452,
  "lon" : 0.8008281904610115,
  "state" : "state",
  "lat" : 6.027456183070403
}, {
  "city" : "city",
  "name" : "name",
  "start" : 5,
  "client" : "client",
  "project" : "project",
  "progression" : 1.4658129805029452,
  "lon" : 0.8008281904610115,
  "state" : "state",
  "lat" : 6.027456183070403
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Show Project Risk Factors
 * Return detailed risk assessment information for all workers on site for a selected day.
 *
 * body Body_2 
 * returns List
 **/
exports.projectsRiskPOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "headcount" : 0,
  "trend" : "trend",
  "change" : 1.4658129805029452,
  "risk" : "risk",
  "id" : "id",
  "workforce_percentage" : 6.027456183070403,
  "workers" : [ {
    "duration" : 5.962133916683182,
    "day_percentage" : 5.637376656633329,
    "name" : "name",
    "id" : "id"
  }, {
    "duration" : 5.962133916683182,
    "day_percentage" : 5.637376656633329,
    "name" : "name",
    "id" : "id"
  } ]
}, {
  "headcount" : 0,
  "trend" : "trend",
  "change" : 1.4658129805029452,
  "risk" : "risk",
  "id" : "id",
  "workforce_percentage" : 6.027456183070403,
  "workers" : [ {
    "duration" : 5.962133916683182,
    "day_percentage" : 5.637376656633329,
    "name" : "name",
    "id" : "id"
  }, {
    "duration" : 5.962133916683182,
    "day_percentage" : 5.637376656633329,
    "name" : "name",
    "id" : "id"
  } ]
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Show Project Timecards
 * Return detailed timecard information for all companies on site for a selected day.
 *
 * body Body_1 
 * returns List
 **/
exports.projectsTimecardsPOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "headcount" : 0,
  "name" : "name",
  "id" : "id",
  "arrival_local" : "arrival_local",
  "workers" : [ {
    "duration" : 5.637376656633329,
    "exit_local" : "exit_local",
    "exit_unix" : 5,
    "name" : "name",
    "id" : "id",
    "arrival_local" : "arrival_local",
    "on_site" : true,
    "arrival_unix" : 1
  }, {
    "duration" : 5.637376656633329,
    "exit_local" : "exit_local",
    "exit_unix" : 5,
    "name" : "name",
    "id" : "id",
    "arrival_local" : "arrival_local",
    "on_site" : true,
    "arrival_unix" : 1
  } ],
  "on_site" : true,
  "arrival_unix" : 6
}, {
  "headcount" : 0,
  "name" : "name",
  "id" : "id",
  "arrival_local" : "arrival_local",
  "workers" : [ {
    "duration" : 5.637376656633329,
    "exit_local" : "exit_local",
    "exit_unix" : 5,
    "name" : "name",
    "id" : "id",
    "arrival_local" : "arrival_local",
    "on_site" : true,
    "arrival_unix" : 1
  }, {
    "duration" : 5.637376656633329,
    "exit_local" : "exit_local",
    "exit_unix" : 5,
    "name" : "name",
    "id" : "id",
    "arrival_local" : "arrival_local",
    "on_site" : true,
    "arrival_unix" : 1
  } ],
  "on_site" : true,
  "arrival_unix" : 6
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Show Project Workforce Composition
 * Return workforce composition information for all subcontractors on site for a selected day.
 *
 * body Body_3 
 * returns inline_response_200_4
 **/
exports.projectsWorkforcePOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "peak_total_manpower" : 0,
  "subcontractors" : [ {
    "headcount" : 6,
    "trend" : "trend",
    "change" : 1.4658129805029452,
    "name" : "name",
    "id" : "id",
    "workers" : [ {
      "name" : "name",
      "id" : "id",
      "arrival_local" : "arrival_local",
      "on_site" : true,
      "arrival_unix" : 5
    }, {
      "name" : "name",
      "id" : "id",
      "arrival_local" : "arrival_local",
      "on_site" : true,
      "arrival_unix" : 5
    } ]
  }, {
    "headcount" : 6,
    "trend" : "trend",
    "change" : 1.4658129805029452,
    "name" : "name",
    "id" : "id",
    "workers" : [ {
      "name" : "name",
      "id" : "id",
      "arrival_local" : "arrival_local",
      "on_site" : true,
      "arrival_unix" : 5
    }, {
      "name" : "name",
      "id" : "id",
      "arrival_local" : "arrival_local",
      "on_site" : true,
      "arrival_unix" : 5
    } ]
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Show Project Work Zones
 * Return detailed location analysis for all workers on site for a selected day.
 *
 * body Body_4 
 * returns List
 **/
exports.projectsZonesPOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = [ {
  "hazards" : [ "hazards", "hazards" ],
  "ppe" : [ "ppe", "ppe" ],
  "production" : [ {
    "activity_name" : "activity_name",
    "company_id" : "company_id",
    "activity_id" : "activity_id",
    "activity_rate" : 6.027456183070403,
    "cost_code" : "cost_code"
  }, {
    "activity_name" : "activity_name",
    "company_id" : "company_id",
    "activity_id" : "activity_id",
    "activity_rate" : 6.027456183070403,
    "cost_code" : "cost_code"
  } ],
  "name" : "name",
  "location" : [ "location", "location" ],
  "id" : "id",
  "total_time" : 0.8008281904610115,
  "certifications" : [ "certifications", "certifications" ],
  "traffic" : [ {
    "name" : "name",
    "id" : "id",
    "total_time" : 1.4658129805029452,
    "workers" : [ {
      "name" : "name",
      "id" : "id",
      "total_time" : 5.962133916683182
    }, {
      "name" : "name",
      "id" : "id",
      "total_time" : 5.962133916683182
    } ]
  }, {
    "name" : "name",
    "id" : "id",
    "total_time" : 1.4658129805029452,
    "workers" : [ {
      "name" : "name",
      "id" : "id",
      "total_time" : 5.962133916683182
    }, {
      "name" : "name",
      "id" : "id",
      "total_time" : 5.962133916683182
    } ]
  } ]
}, {
  "hazards" : [ "hazards", "hazards" ],
  "ppe" : [ "ppe", "ppe" ],
  "production" : [ {
    "activity_name" : "activity_name",
    "company_id" : "company_id",
    "activity_id" : "activity_id",
    "activity_rate" : 6.027456183070403,
    "cost_code" : "cost_code"
  }, {
    "activity_name" : "activity_name",
    "company_id" : "company_id",
    "activity_id" : "activity_id",
    "activity_rate" : 6.027456183070403,
    "cost_code" : "cost_code"
  } ],
  "name" : "name",
  "location" : [ "location", "location" ],
  "id" : "id",
  "total_time" : 0.8008281904610115,
  "certifications" : [ "certifications", "certifications" ],
  "traffic" : [ {
    "name" : "name",
    "id" : "id",
    "total_time" : 1.4658129805029452,
    "workers" : [ {
      "name" : "name",
      "id" : "id",
      "total_time" : 5.962133916683182
    }, {
      "name" : "name",
      "id" : "id",
      "total_time" : 5.962133916683182
    } ]
  }, {
    "name" : "name",
    "id" : "id",
    "total_time" : 1.4658129805029452,
    "workers" : [ {
      "name" : "name",
      "id" : "id",
      "total_time" : 5.962133916683182
    }, {
      "name" : "name",
      "id" : "id",
      "total_time" : 5.962133916683182
    } ]
  } ]
} ];
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

