'use strict';


/**
 * Get Or Refresh An Access Token
 * Used to acquire a new access token or refresh an existing access token. Certain parameter combinations and values are used depending on which scenario you are handling.  **Basic Authorization header containing your WorkerSense account email and password is required only for \"password\" grant types.**
 *
 * body Body 
 * returns inline_response_200
 **/
exports.oauthTokenPOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "access_token" : "access_token",
  "refresh_token" : "refresh_token",
  "expires" : 0,
  "token_type" : "token_type"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

