'use strict';

var utils = require('../utils/writer.js');
var Project = require('../service/ProjectService');

module.exports.projectsGET = function projectsGET (req, res, next) {
  Project.projectsGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.projectsRiskPOST = function projectsRiskPOST (req, res, next, body) {
  Project.projectsRiskPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.projectsTimecardsPOST = function projectsTimecardsPOST (req, res, next, body) {
  Project.projectsTimecardsPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.projectsWorkforcePOST = function projectsWorkforcePOST (req, res, next, body) {
  Project.projectsWorkforcePOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.projectsZonesPOST = function projectsZonesPOST (req, res, next, body) {
  Project.projectsZonesPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
